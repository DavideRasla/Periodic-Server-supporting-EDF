#include <stdlib.h>
#include <stdio.h>

#include "task_io.h"
#include "dbf.h"
#include "sbf.h"

static void h_do(struct taskset *ts, unsigned int q_s, unsigned int t_s)
{
  unsigned int t[128];
  int n;
  unsigned int i;
  int schedulable = 1;

  printf("Q = %u, P = %u: ", q_s, t_s);
  i = 0; n = 1;
  while(n > 0) {

    n = scheduling_points(ts, i, t, 128);
    if (n > 0) {
      unsigned int task_schedulable = 0;
      unsigned int j;

      for (j = 0; j < (unsigned int)n; j++) {
        if (dbf(ts, i, t[j]) <= sbf(q_s, t_s, t[j])) task_schedulable = 1;
      }
      if (task_schedulable == 0) schedulable = 0;
    }
    i++;
  }
  printf("\t\tSchedulable: %d", schedulable);
  if (schedulable) printf(" %f", (double)q_s / (double)t_s);
  printf("\n");
}

int main(int argc, char *argv[])
{
  FILE *in;
  struct taskset *ts;
  unsigned int q, t;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <taskset>\n", argv[0]);

    return -1;
  }

  in = fopen(argv[1], "r");
  if (in == NULL) {
    perror("FOpen");

    return -2;
  }
  ts = ts_load(in);
  if (ts == NULL) {
    fprintf(stderr, "Error loading taskset!\n");

    return -3;
  }
  printf("Taskset:\n");
  ts_print(ts, stdout);

  /* BIG FAT WARNING:
   * The minimum and maximum values for P_s are arbitrary numbers, here!!!
   * The minimum value for Q_s is also arbitrary!!!
   * You can do something much smarter...
   */
  for (t = 2; t < 500; t++) {
    for (q = 1; q < t; q++) {
      h_do(ts, q, t);
    }
  }


  return 0;
}

