struct task {
  unsigned int c;
  unsigned int d;
  unsigned int p;
};
