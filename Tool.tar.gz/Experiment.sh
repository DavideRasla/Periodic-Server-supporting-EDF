#!/bin/sh


U=0.0
N=3
stringvar="gen"
S=${S:-8}
USET=${USET:-10}
TS=${TS:-TaskSets}
UT=${UT:-Utilization}
RESULTS_EDF=${RESULTS_EDF:-Results_EDF}
RESULTS_RM=${RESULTS_RM:-Results_RM}
generate_ts() {
  python2 taskgen.py -S $1 -d logunif -s 1 -n $N -u $U -p 20 -q 300 -g 10 --round-C -f "%(C)d %(T)d %(T)d\n" #-S = seed; -q = MaxPeriod; -p = MinPeriod
#  $mydir/taskgen.py -S $1 -d logunif -s 1 -n $N -u $U -p 5000 -q 500000 -g 1000 --round-C -f "%(Ugen)f\n" | head -n -1
}


if [ $1 -gt 1 ] #if argument is greater than 1
then 

    sudo rm -rf $TS
    N=$1 #Creates as many tasks as specified in input
    echo "Generate $N new tasks for each taskset"

    for I in $(seq 1 $S);
    do
        mkdir -p $TS/$UT"0."$I
    done

    for I in $(seq 1 $S);
    do
        incl=0.1
        U=`echo $U + $incl | bc`
        echo "0"$U
        for J in $(seq 1 $USET);#Creates 10 taskset for each utilization
            do
                echo "Generating Taskset $J with utilization 0$U"
                generate_ts $J > $TS/$UT"0."$I/ts$J.txt #J is used as a seeds
            done
    done


    U=0.0
    sudo rm -rf $RESULTS_EDF
    sudo rm -rf $RESULTS_RM
    mkdir -p $RESULTS_EDF
    mkdir -p $RESULTS_RM
    chmod +x h_design 
    chmod +x h_design_RM 



    for I in $(seq 1 $S);#for each Utilization
    do
        incl=0.1
        U=`echo $U + $incl | bc`
        echo "New Utilization: 0$U"
        for J in $(seq 1 $USET);#For each taskset 
            do
                echo "Calculating U for Taskset $J"
                ./h_design $TS/$UT"0."$I/ts$J.txt >>$RESULTS_EDF/EDF_0.$I.txt
                ./h_design_RM $TS/$UT"0."$I/ts$J.txt >>$RESULTS_RM/RM_0.$I.txt
            done
    done
fi
python3 Plot_Graph.py $N


