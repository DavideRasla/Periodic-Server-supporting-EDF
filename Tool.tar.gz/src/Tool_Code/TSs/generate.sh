#!/bin/sh

mydir=$(realpath $(dirname $0))
U=$2
N=$1
S=${S:-10}
TS=${TS:-TaskSets}

generate_ts() {
  python2 taskgen.py -S $1 -d logunif -s 1 -n $N -u $U -p 20 -q 300 -g 10 --round-C -f "%(C)d %(T)d %(T)d\n"
#  $mydir/taskgen.py -S $1 -d logunif -s 1 -n $N -u $U -p 5000 -q 500000 -g 1000 --round-C -f "%(Ugen)f\n" | head -n -1
}

mkdir -p $TS 
for I in $(seq 1 $S);
 do
  echo "Generating Taskset $I"
  generate_ts $I > $TS/ts$I.txt
 done 
