#include <stdlib.h>
#include <stdio.h>

#include "task_io.h"
#include "dbf.h"
#include "sbf.h"
#include "taskset.h"
#include "task.h"
#define POS_MAX_PER 1
#define POS_MIN_PER 0

double Min_U = 1;
unsigned int Optimal_Q = 0;
unsigned int Optimal_P = 0;
static void h_do(struct taskset *ts, unsigned int q_s, unsigned int t_s)
{
  unsigned int t[128];
  int n;
  unsigned int i;
  int schedulable = 1;

 // printf("Q = %u, P = %u: ", q_s, t_s);
  i = 0; n = 1;
  while(n > 0) {

    n = scheduling_points(ts, i, t, 128);
    if (n > 0) {
      unsigned int task_schedulable = 0;
      unsigned int j;
      
      for (j = 0; j < (unsigned int)n; j++) {
        if (dbf(ts, i, t[j]) <= sbf(q_s, t_s, t[j])) task_schedulable = 1;
      }
      if (task_schedulable == 0) schedulable = 0;
    }
    i++;
  }
  if(schedulable){
    printf("Q = %u, P = %u: ", q_s, t_s);
   printf("\t\tSchedulable: %d\n", schedulable); //comment this in order to avoid verbosity
    if (schedulable) 
    {
      printf("US = %f\n", (double)q_s / (double)t_s);
      if( ((double)q_s / (double)t_s ) < Min_U){
        Min_U =  (double)q_s / (double)t_s;
        Optimal_P = t_s;
        Optimal_Q = q_s;
      }
    }
   // printf("\n");
  }
}


int main(int argc, char *argv[])
{
  FILE *in;
  struct taskset *ts;
  unsigned int q, t;
  unsigned int Periods_Min_Max[2]; // [0]: Min_Period, [1]: MaxPeriod
  double Utilization_TaskSet = 0;
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <taskset>\n", argv[0]);

    return -1;
  }

  in = fopen(argv[1], "r");
  if (in == NULL) {
    perror("FOpen");

    return -2;
  }
  ts = ts_load(in);
  if (ts == NULL) {
    fprintf(stderr, "Error loading taskset!\n");

    return -3;
  }
  printf("Taskset Pre ordering:\n");
  ts_print(ts, stdout);
  
  qsort(ts->tasks, ts->size, sizeof(struct task), cmpfunc_Task); //reordering the taskset 
  
  printf("Taskset Post ordering:\n");
  ts_print(ts, stdout);

  GetPeriod(ts, Periods_Min_Max);

  Utilization_TaskSet = CalcU(ts);

  for (t = (int)(Periods_Min_Max[POS_MIN_PER]); t < Periods_Min_Max[POS_MAX_PER] * 3; t++) {
    for (q = floor(Utilization_TaskSet * t); q < t; q++) {
      h_do(ts, q, t);
    }
  }
  if (Optimal_P != 0 && Optimal_Q != 0) {
    printf("Il Q ottimale e': %d \n", Optimal_Q);
    printf("Il P ottimale e': %d \n", Optimal_P);
    printf("%f \n", Min_U);
  } else {
    printf("Did not found any Q and P\n");
  }
 // printf("Taskset Post ordering:\n");
 // ts_print(ts, stdout);

  return 0;
}


