unsigned int sbf(unsigned int q, unsigned int t, unsigned int s);

