import array as arr
import matplotlib.pyplot as plt
import numpy as np
import sys

#Calculating average for EDF
AVG_EDF = arr.array('f', [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
for iter in range(0,8):
   fileName = "Results_EDF/EDF_0."+str(iter + 1)+".txt"
   file_EDF = open(fileName,"r+")
   file_list = file_EDF.readlines()
   for row in file_list:
       #print(row)
       AVG_EDF[iter] += float(row)
   AVG_EDF[iter] /= len(file_list)

    

#Calculating average for RM 
AVG_RM = arr.array('f', [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
for iter in range(0,8):
   fileName = "Results_RM/RM_0."+str(iter + 1)+".txt"
   file_RM = open(fileName,"r+")
   file_list = file_RM.readlines()
   for row in file_list:
       #print(row)
       AVG_RM[iter] += float(row)
   AVG_RM[iter] /= len(file_list)

print("EDF: ", AVG_EDF)
print("RM: ",AVG_RM)

plt.xlabel('Taskset utilization')
plt.ylabel('Average Q/P')
title = "Compare between EDF and RM with " + str(sys.argv[1]) + " tasks"
plt.title(title)
plt.axis([0,7, 0.5, 1])
locs, labels = plt.xticks()
plt.xticks(np.arange(0, 7, step=0.01))
plt.xticks(np.arange(7), ('0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8', ))
plt.xticks(np.arange(12), rotation=0)
plt.grid(True)
plt.plot(AVG_EDF,'-x', label = "EDF")
plt.plot(AVG_RM,'-x', label = "RM")

plt.legend()
plt.show()