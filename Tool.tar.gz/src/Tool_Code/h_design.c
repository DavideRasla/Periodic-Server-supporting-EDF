#include <stdlib.h>

#include <stdio.h>

#include "taskset.h"

#include "task_io.h"

#include "dbf.h"

#include "sbf.h"

#include "task.h"

#include <math.h>

#define MINIMUM_PERIOD_CONST 5
#define POS_MAX_PER 1
#define POS_MIN_PER 0
int Q_Optimum = 0;
int P_Optimum = 0;
double min_U = 1;

void h_do(const struct taskset * ts, unsigned int q_s, unsigned int t_s) {
  unsigned int sp[128];

  unsigned int i = 0;
  int schedulable = 1;
  unsigned int dbf = 0;

  unsigned int n = D_Set_EDF(ts, sp, 128);
  unsigned int Sched_point_notfeasible = 0;
  if (n > 0) {
   for (unsigned int j = 0; j < n; j++) { //for each SP
   dbf = 0;
   i = 0;
    while (i < ts->size) { // for each task
      
       // printf("Q vale : %d, P vale :%d \n", q_s, t_s);
      
       // printf("My EDF vale : %d \n", my_EDF_G( ts->tasks[i].d, sp[j], ts->tasks[i].p ) );
       // printf("My EDF * ci vale : %d \n", my_EDF_G( ts->tasks[i].d, sp[j], ts->tasks[i].p ) * ts->tasks[i].c);
       // printf("Sbf vale : %d \n", sbf(q_s, t_s, sp[j]));
        //printf("Lo sched point è: %d \n\n", sp[j]);
        
        dbf += my_EDF_G(ts->tasks[i].d, sp[j], ts->tasks[i].p) * ts->tasks[i].c;
      
      i++;
    }
   // printf("Dbf(%d) = %d\n", sp[j], dbf );
      
    if (dbf > sbf(q_s, t_s, sp[j])) { 
      schedulable = 0; //The condition must satisy each SP
      Sched_point_notfeasible = j;
      break;
    } 
   }


    if (schedulable) {
      printf("schedulable with Q = %u, P = %u: ", q_s, t_s);
      printf("Dbf() = %d\n", dbf );
      printf("\t\tSchedulable: YES");
      printf(" Us = %f\n\n", (double) q_s / (double) t_s);

      if (((double) q_s / (double) t_s) < min_U) { //Saving the optimal Q and P
        min_U = (double) q_s / (double) t_s;
        Q_Optimum = q_s;
        P_Optimum = t_s;
      }
      printf("\n");
    }else{
      printf("\nNot schedulable with Q = %d and P = %d; dbf(t) = %d > sbf(t) = %d when in Sched point %d\n", q_s, t_s, dbf ,sbf(q_s, t_s, sp[Sched_point_notfeasible]), sp[Sched_point_notfeasible] );
    }

  }

}

int main(int argc, char * argv[]) {
  FILE * in ;

  unsigned int q, t;
  struct taskset * ts_Des;
  unsigned int Periods_Min_Max[2]; // [0]: Min_Period, [1]: MaxPeriod
  double Utilization_TaskSet = 0;
  unsigned int sp[128];
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <taskset>\n", argv[0]);

    return -1;
  }

  in = fopen(argv[1], "r");
  if ( in == NULL) {
    perror("FOpen");

    return -2;
  }
  ts_Des = ts_load( in );
  if (ts_Des == NULL) {
    fprintf(stderr, "Error loading taskset!\n");

    return -3;
  }
  //printf("Taskset:\n");
  qsort(ts_Des->tasks, ts_Des->size, sizeof(struct task), cmpfunc_Task); //reordering the taskset 
  
  //ts_print(ts_Des, stdout);

  if (CalcU(ts_Des) > 1) {
    printf("Taskset with U = %f > 1\n", CalcU(ts_Des));
    return 0;
  } else {
      printf("First condition checked: U = %f < 1\n", CalcU(ts_Des));
  }
  
  unsigned int minL_H = (CalcLSTAR(ts_Des) > CalcH(ts_Des)) ? CalcH(ts_Des) : CalcLSTAR(ts_Des);
  //printf("MIN (L*, H) = %d,\n", minL_H);
 // printf("Lstar :%d ", CalcLSTAR(ts_Des));
 // printf("H: %d\n", CalcH(ts_Des));
  unsigned int n = D_Set_EDF(ts_Des, sp, 128);
  //printf("D = {");
  for (unsigned int i = 0; i < n; i++)
  {
   // printf("%d, ", sp[i]);
  }
  //printf("}\n");

  GetPeriod(ts_Des, Periods_Min_Max);

  Utilization_TaskSet = CalcU(ts_Des);

  for (t = (int)(Periods_Min_Max[POS_MIN_PER]); t < Periods_Min_Max[POS_MAX_PER] * 3; t++) {
    for (q = floor(Utilization_TaskSet * t); q < t; q++) {
      h_do(ts_Des, q, t);
    }
  }
  if (Q_Optimum != 0 && P_Optimum != 0) {
    printf("\nIl Q ottimale e': %d \n", Q_Optimum);
    printf("Il P ottimale e': %d \n", P_Optimum);
    printf("Us = %f \n", min_U);
    printf("Ut = %f < 1\n", CalcU(ts_Des));
  } else {
    printf("Not schedulable\n");
  }
 //printf("Taskset:\n");
 // ts_print(ts_Des, stdout);

  return 0;
}

/*
my_EDF_G( ts->tasks[i].d, sp[j], ts->tasks[i].p ) * ts->tasks[i].c implements MAX{ 0, floor( (t + Ti - Di) / Ti ) } * Ci 

*/